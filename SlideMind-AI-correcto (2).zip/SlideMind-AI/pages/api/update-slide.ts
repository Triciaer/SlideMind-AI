export async function POST(req) {
  const { slide } = await req.json();
  const prompt = `Actualiza el contenido de la siguiente diapositiva para que tenga datos verificados hasta 2025 y añade una fuente con enlace. Devuelve un JSON con {title, content, source}. Diapositiva: ${JSON.stringify(slide)}`;

  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.5,
    }),
  });

  const result = await res.json();
  let updatedSlide;
  try {
    updatedSlide = JSON.parse(result.choices[0].message.content);
  } catch {
    updatedSlide = { title: slide.title, content: slide.content, source: "" };
  }

  return new Response(JSON.stringify(updatedSlide), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
}