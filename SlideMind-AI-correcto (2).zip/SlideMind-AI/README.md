# SlideMind AI

Generador de presentaciones con IA y verificación de datos.