export async function POST(req) {
  const { topic } = await req.json();
  const prompt = `Crea una presentación educativa de 4 diapositivas sobre el tema: "${topic}". Cada diapositiva debe tener un título, un contenido breve, claro y con datos verificados hasta 2025. Si mencionas estadísticas, incluye la fuente con un enlace. Devuélvelo en formato JSON con la estructura: [{title: "", content: "", source: ""}, ...]`;

  const openaiRes = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
    }),
  });

  const openaiData = await openaiRes.json();
  const content = openaiData.choices[0].message.content;

  let slides;
  try {
    slides = JSON.parse(content);
  } catch (e) {
    slides = [{ title: "Error de formato", content: "La respuesta de la IA no se pudo interpretar. Intenta de nuevo." }];
  }

  return new Response(JSON.stringify({ slides }), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
}