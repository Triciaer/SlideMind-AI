import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";

export default function SlideMindAI() {
  const [topic, setTopic] = useState("");
  const [presentation, setPresentation] = useState([]);
  const [loading, setLoading] = useState(false);

  const generatePresentation = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/generate-presentation", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ topic }),
      });

      if (!response.ok) throw new Error("Error al generar presentación");

      const data = await response.json();
      setPresentation(data.slides);
    } catch (error) {
      console.error(error);
      setPresentation([{ title: "Error", content: "Hubo un problema al generar la presentación. Intenta de nuevo." }]);
    } finally {
      setLoading(false);
    }
  };

  const updateSlideData = async (index) => {
    const slide = presentation[index];
    const response = await fetch("/api/update-slide", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slide }),
    });
    const updatedSlide = await response.json();
    const newSlides = [...presentation];
    newSlides[index] = updatedSlide;
    setPresentation(newSlides);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-4 text-center">SlideMind AI</h1>
      <Card className="mb-6">
        <CardContent className="space-y-4 p-4">
          <Input
            placeholder="Ingresa el tema de tu presentación"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
          />
          <Button onClick={generatePresentation} disabled={loading}>
            {loading ? "Generando..." : "Generar Presentación"}
          </Button>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {presentation.map((slide, index) => (
          <Card key={index} className="bg-white shadow p-4">
            <h2 className="text-xl font-semibold">{slide.title}</h2>
            <p className="mt-2 text-gray-700">{slide.content}</p>
            <div className="mt-4 flex gap-2">
              <Button variant="outline" onClick={() => updateSlideData(index)}>
                Actualizar datos
              </Button>
              {slide.source && (
                <a
                  href={slide.source}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 underline"
                >
                  Ver fuente
                </a>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
